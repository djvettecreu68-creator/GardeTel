package com.hack68.gardetel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private val BG = 0xFF0F1115.toInt()
    private val CARD = 0xFF1A1D24.toInt()
    private val GREEN = 0xFF22C55E.toInt()
    private val RED = 0xFFEF4444.toInt()
    private val AMBER = 0xFFF59E0B.toInt()
    private val GREY = 0xFF9CA3AF.toInt()
    private val WHITE = 0xFFFFFFFF.toInt()

    private lateinit var card: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var statusSub: TextView
    private lateinit var toggleBtn: Button
    private lateinit var sensLabel: TextView
    private lateinit var batteryBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences(GuardService.PREFS, MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun text(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun bigButton(label: String, color: Int) = Button(this).apply {
        text = label; setTextColor(WHITE); textSize = 16f
        background = rounded(color, 14); stateListAnimator = null
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun lp(top: Int = 16) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }

        root.addView(text(28f, WHITE, true).apply { text = "🛡️ Garde Tél" })
        root.addView(text(14f, GREY).apply {
            text = "Alerte dans ton casque si quelqu'un prend le téléphone"
        }, lp(6))

        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        statusText = text(30f, WHITE, true)
        statusSub = text(15f, GREY)
        card.addView(statusText)
        card.addView(statusSub, lp(8))
        root.addView(card, lp(28))

        toggleBtn = bigButton("ACTIVER", GREEN)
        toggleBtn.textSize = 20f
        toggleBtn.setOnClickListener { toggle() }
        root.addView(toggleBtn, lp(20))

        // Sensibilité
        sensLabel = text(15f, WHITE)
        root.addView(sensLabel, lp(28))
        val seek = SeekBar(this).apply {
            max = 9
            progress = prefs.getInt(GuardService.KEY_SENS, 6) - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    prefs.edit().putInt(GuardService.KEY_SENS, p + 1).apply()
                    updateSensLabel()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(seek, lp(4))
        root.addView(text(12f, GREY).apply {
            text = "Appliquée à la prochaine activation"
        }, lp(2))
        updateSensLabel()

        root.addView(bigButton("🔊 Tester le son dans le casque", CARD).apply {
            setOnClickListener { testSound() }
        }, lp(24))

        batteryBtn = bigButton("🔋 Autoriser en arrière-plan (batterie)", CARD).apply {
            setOnClickListener { askBattery() }
        }
        root.addView(batteryBtn, lp(12))

        root.addView(text(13f, GREY).apply {
            text = "Active, pose le téléphone : il s'arme en 5 s. Tu peux fermer l'appli " +
                "et éteindre l'écran, la surveillance continue. Pour couper : bouton ici " +
                "ou « Désactiver » dans la notification (déverrouillage requis)."
        }, lp(24))

        val scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(root)
        }
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        GuardService.listener = { s -> runOnUiThread { render(s) } }
        render(GuardService.state)
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        batteryBtn.visibility = if (pm.isIgnoringBatteryOptimizations(packageName)) View.GONE else View.VISIBLE
    }

    override fun onPause() {
        GuardService.listener = null
        super.onPause()
    }

    private fun toggle() {
        val i = Intent(this, GuardService::class.java)
        if (GuardService.state == GuardService.State.OFF) {
            startForegroundService(i.setAction(GuardService.ACTION_START))
        } else {
            startService(i.setAction(GuardService.ACTION_STOP))
        }
    }

    private fun render(s: GuardService.State) {
        when (s) {
            GuardService.State.OFF -> {
                statusText.text = "⚪ INACTIVE"
                statusSub.text = "Le téléphone n'est pas surveillé"
                card.background = rounded(CARD)
                toggleBtn.text = "ACTIVER"
                toggleBtn.background = rounded(GREEN, 14)
            }
            GuardService.State.ARMING -> {
                statusText.text = "🟡 ARMEMENT…"
                statusSub.text = "Pose le téléphone, activation dans 5 s"
                card.background = rounded(0xFF3A2E0F.toInt()).apply { setStroke(dp(2), AMBER) }
                toggleBtn.text = "DÉSACTIVER"
                toggleBtn.background = rounded(RED, 14)
            }
            GuardService.State.ACTIVE -> {
                statusText.text = "🟢 ACTIVE"
                statusSub.text = "Surveillance en cours, tu peux fermer l'appli"
                card.background = rounded(0xFF0F2A1A.toInt()).apply { setStroke(dp(2), GREEN) }
                toggleBtn.text = "DÉSACTIVER"
                toggleBtn.background = rounded(RED, 14)
            }
            GuardService.State.ALARM -> {
                statusText.text = "🚨 ALERTE"
                statusSub.text = "Le téléphone a bougé !"
                card.background = rounded(0xFF3A1010.toInt()).apply { setStroke(dp(2), RED) }
                toggleBtn.text = "DÉSACTIVER"
                toggleBtn.background = rounded(RED, 14)
            }
        }
    }

    private fun updateSensLabel() {
        sensLabel.text = "Sensibilité : ${prefs.getInt(GuardService.KEY_SENS, 6)}/10"
    }

    private fun testSound() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
            tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1500)
            handler.postDelayed({ tg.release() }, 1800)
        } catch (_: Exception) {}
    }

    private fun askBattery() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}
