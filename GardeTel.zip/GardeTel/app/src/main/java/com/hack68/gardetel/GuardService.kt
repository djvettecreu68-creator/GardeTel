package com.hack68.gardetel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import kotlin.math.sqrt

class GuardService : Service(), SensorEventListener {

    enum class State { OFF, ARMING, ACTIVE, ALARM }

    companion object {
        const val ACTION_START = "com.hack68.gardetel.START"
        const val ACTION_STOP = "com.hack68.gardetel.STOP"
        const val CHANNEL_ID = "garde_status"
        const val NOTIF_ID = 42
        const val ARM_DELAY_MS = 5000L
        const val PREFS = "garde"
        const val KEY_SENS = "sensibilite"

        @Volatile
        var state: State = State.OFF
        var listener: ((State) -> Unit)? = null

        // Sensibilité 1..10 -> seuil 3.0 .. 0.3 m/s²
        fun threshold(sens: Int): Float = 3.3f - sens * 0.3f
    }

    private lateinit var sensorManager: SensorManager
    private var accel: Sensor? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var tone: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())

    private val filt = FloatArray(3)
    private val base = FloatArray(3)
    private val calibSum = FloatArray(3)
    private var calibSamples = 0
    private var calibrating = false
    private var thresholdValue = 1.5f
    private var lastAlarm = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val ch = NotificationChannel(CHANNEL_ID, "État de la surveillance", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        startGuard()
        return START_STICKY
    }

    private fun startGuard() {
        handler.removeCallbacksAndMessages(null)
        stopSensor()
        val sens = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_SENS, 6)
        thresholdValue = threshold(sens)
        lastAlarm = 0L

        state = State.ARMING
        val n = buildNotif()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        listener?.invoke(state)

        if (wakeLock == null) {
            wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GardeTel::guard")
                .apply { setReferenceCounted(false); acquire() }
        }
        if (tone == null) {
            tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 100) } catch (e: Exception) { null }
        }
        handler.postDelayed({ beginCalibration() }, ARM_DELAY_MS)
    }

    private fun beginCalibration() {
        val s = accel ?: run { shutdown(); return }
        calibrating = true
        calibSamples = 0
        calibSum.fill(0f)
        sensorManager.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val v = e.values
        if (calibrating) {
            for (i in 0..2) calibSum[i] += v[i]
            calibSamples++
            if (calibSamples >= 15) {
                for (i in 0..2) {
                    base[i] = calibSum[i] / calibSamples
                    filt[i] = base[i]
                }
                calibrating = false
                setState(State.ACTIVE)
            }
            return
        }

        for (i in 0..2) filt[i] = filt[i] * 0.7f + v[i] * 0.3f
        val dx = filt[0] - base[0]
        val dy = filt[1] - base[1]
        val dz = filt[2] - base[2]
        val diff = sqrt(dx * dx + dy * dy + dz * dz)
        val now = SystemClock.elapsedRealtime()

        if (diff > thresholdValue) {
            if (now - lastAlarm > 2000) {
                lastAlarm = now
                tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1500)
            }
            if (state != State.ALARM) setState(State.ALARM)
        } else if (state == State.ALARM && now - lastAlarm > 5000) {
            setState(State.ACTIVE)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun setState(s: State) {
        state = s
        if (s != State.OFF) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotif())
        }
        listener?.invoke(s)
    }

    private fun buildNotif(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, GuardService::class.java).setAction(ACTION_STOP), flags
        )
        val (title, text) = when (state) {
            State.ARMING -> "🟡 Armement…" to "Pose le téléphone, surveillance dans 5 s"
            State.ALARM -> "🚨 ALERTE : téléphone déplacé !" to "Appuie sur Désactiver pour couper"
            else -> "🟢 Surveillance ACTIVE" to "Alerte dans ton casque si on le bouge"
        }
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Désactiver", stop
        )
        // Empêche quelqu'un de couper l'alarme depuis l'écran verrouillé
        if (Build.VERSION.SDK_INT >= 31) action.setAuthenticationRequired(true)

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setContentIntent(open)
            .addAction(action.build())
            .build()
    }

    private fun stopSensor() {
        sensorManager.unregisterListener(this)
        calibrating = false
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        stopSensor()
        tone?.release()
        tone = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        state = State.OFF
        listener?.invoke(State.OFF)
    }

    private fun shutdown() {
        cleanup()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (state != State.OFF) cleanup()
        super.onDestroy()
    }
}
